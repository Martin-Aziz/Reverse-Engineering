# Team19 - Lösungen und weiteres

## Message @ OfficerLou
Struktur wurde jetzt wie gewünscht umgesetzt. Ältere Aufgaben (pre Assignment_09) werden nachträglich eingebettet.

---

### Lösungen:


|   Aufgabe	|  Link	|  Flags |
|---	|:---:	|:---:	|
|   Nr. 1	|   [Lösung]	|   |   
|   Nr. 2	|   [Lösung]    |   |  
|   Nr. 3	|   [Lösung]	|   |
|   Nr. 4	|   [Lösung]	|   |
|   Nr. 5 	|   [Lösung]	|   |
|   Nr. 6	|   [Lösung]	|   |
|   Nr.7	|  [Lösung] 	|   |
|   Nr. 8	|  [Lösung] 	|   |
|   Nr. 9	|  [Lösung](https://gitty.informatik.hs-mannheim.de/ree-lecture/team-19/src/branch/main/Assignement_09) 	|  {humpydumpy} |
|   Nr. 10	|   [Lösung]	|
|   Nr. 11	|   [Lösung]	|  
|   Nr. 12	|   [Lösung]	|  
|   Nr. 13	|   [Lösung]	|  
|   Nr. 14	|   [Lösung]	|    
|   Nr. 15	|   [Lösung]	|    |
|   Nr. 16	|   [Lösung](https://gitty.informatik.hs-mannheim.de/ree-lecture/team-19/src/branch/main/Assignment_16)   |   |
|   Nr. 17      |   [Lösung]    |
|   Nr. 18      |   [Lösung]    |  
|   Nr. 19      |   [Lösung]    |  
|   Nr. 20      |   [Lösung]    |  
|   Nr. 21      |   [Lösung](https://gitty.informatik.hs-mannheim.de/ree-lecture/team-19/src/branch/main/Assignment_21)    |    
|   Nr. 22      |   [Lösung]    |    |
|   Nr. 23      |   [Lösung]    |   |
