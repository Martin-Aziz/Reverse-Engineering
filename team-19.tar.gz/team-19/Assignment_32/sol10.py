overflow = ['0' for x in range(44)]
print(''.join(overflow))