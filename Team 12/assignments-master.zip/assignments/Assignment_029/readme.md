# Assignment: Disassemblieren einer Payload (payload_7.bin)



Bei einem Security-Assessment wurde eine Payload gefunden, die von einem Angreifer in ein laufendes System injiziert wurde. Diese liegt Ihnen vor und soll nun analysiert werden.

Ihre Aufgabe ist es, die Payload mit einer statischen Analyse zu untersuchen, *ohne sie auszuführen*, da davon auszugehen ist, dass es sich um eine Schadsoftware handelt.


## Hinweis

Bei dem Executable handelt es sich um ein Programm unbekannter Funktionalität, wie man sie z.B. bei der Untersuchung von kompromittierten Rechner finden könnte. Es kann gut sein, dass es sich um eine _Malware_ handelt, welche bei der Ausführung Schaden verursacht, bis hin zur Zerstörung aller Daten auf dem Rechner. Deswegen sollten Sie die Datei __auf keinen Fall__ ohne Schutzmaßnahmen (virtuelle Maschine etc.) __ausführen__. Die hier vorgenommene Analyse kommt ohne Ausführung der Datei aus und ist insofern sicher auch ohne Schutzmaßnahmen durchführbar.

Sie müssen in der Realität damit rechnen, dass die Malware Schwachstellen in den von Ihnen verwendeten Werkzeugen nutzt, um bei einem Reverse-Engineering Ihren Rechner anzugreifen. Da wir uns hier in einem Übungskontext befinden, ignorieren wir dieses Problem.


## Ghidra

Diese Aufgabe verwendet [Ghidra](https://ghidra-sre.org/), ein umfangreiches Reverse-Engineering-Tool, das von der NSA entwickelt und als Open-Source-Lösung frei zur Verfügung gestellt wird.

Laden Sie Ghidra herunter und installieren Sie es auf Ihrem Rechner.

## Aufgabe

Sie finden die Payload in der folgenden Datei:

  * [payload_7.bin](payload_7.bin)

Verwenden Sie ghidra, um den Inhalt zu analysieren.

Öffnen Sie die Datei in Ghidra. Da es sich um eine Payload handelt, sind keine weiteren Informationen verfügbar, sodass Sie Ghidra sowohl die Architektur (x86 64bit) als auch den Compiler vorgeben müssen (gcc).

Nach dem Öffnen in Ghidra werden Sie wahrscheinlich keine sinnvolle Anzeige sehen. Gehen Sie auf das erste Byte und drücken Sie `d`, um den Code zu disassemblieren.

Nur der erste Teil des Codes ergibt Sinn, der Rest (ab der `jl`-Instruktion) ist unsinnig.

Versuchen Sie nun, einen Weg zu finden, das Verhalten des Codes zu analysieren, ohne ihn auszuführen. Insbesondere der Teil nach der `jl`-Instruktion ist interessant.


## Abgabe

  * Schreiben Sie auf, wie Sie vorgegangen sind, und zwar so, dass ein fachkundiger Dritter Ihre Schritte nachvollziehen kann.
  * Gab es Probleme?
  * Welche Information konnten Sie extrahieren?
  * Falls es ein Flag gab, wie lautete das Flag?

Die Abgabe erfolgt über das Repository, das Ihrem Team zugeordnet ist.

Bitte legen Sie im Wurzelverzeichnis Ihres Repos eine Datei `readme.md` an, die einen Überblick über die Assignments und Write-Ups liefert. Die WritUps sollten von dieser Datei aus verlinkt sein. Gestalten Sie das Repo so, dass man sich leicht und schnell zurechtfinden kann.