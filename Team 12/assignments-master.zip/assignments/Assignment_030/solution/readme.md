# Lösung: Analyse mit Ghidra (pwnable 21)

Das Programm berücksichtigt nicht den Rückgabewert der Funktion `malloc` und geht naiv davon aus, dass `malloc` niemals einen Fehler hat. Wenn man aber mehr Speicher anfordert, als `malloc` liefern kann, dann gibt es `(void*)0` zurück.

Das Programm gibt die Adresse des Pointers auf die Variable aus, welche die Ausgabe des Flags kontrolliert. Nach dem Lesen der Daten schreibt es `'\0'` an das Ende des eingelesenen Buffers (`readBuffer[length - 1] = '\0';`), um eine korrekte Terminierung des Strings zu gewährleisten. Genau hier setzt der Angriff an:

  * Man nimmt die Adresse des Pointers (z.B. 0x7fcf03a35010) und fordert ein Byte mehr Speicher an (z.B. 140527095992337).
  * Malloc kann so viel Speicher nicht beschaffen und gibt `0` zurück, sodass `readBuffer` den Wert `0` hat.
  * Der Schreibzugriff geht dann auf `(0 + length - 1)` und somit genau auf die Adresse der Kontrollvariable.
  * Das Flag wird ausgegeben.
