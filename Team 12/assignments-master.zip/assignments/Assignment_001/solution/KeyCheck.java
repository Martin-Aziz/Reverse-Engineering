public class KeyCheck {

    public boolean checkKey(String key) {
        return true;
    }
}
