# Reverse Engineering (Wintersemester 2023/2024)

## Willkommen zum Kurs Reverse Engineering (REE)

In diesem Kurs erfahren Sie, wie man einem unbekannten Binärartefakt (Programm, Virus, Payload) seine Geheimnisse entlocken kann. Hierzu werden Sie grundlegende Techniken der Analyse solcher Programme erlernen und diese Techniken verwenden, um deren Funktionsweise zu verstehen und Schwachstellen zu finden. Am Ende des Kurses werden Sie in der Lage sein, einfache CTFs (Capture The Flag) aus dem Bereich des Reverse Engineerings zu lösen und eigene kleinere Aufgaben für Ihre Mitstudierenden zu entwickeln, die diese dann lösen müssen.


## Assignments

Hier finden Sie die wöchentlichen Assignments für die Vorlesung Reverse Engineering (RE). Die Assignments sind unten, zusammen mit dem Fälligkeitsdatum, aufgelistet.

Einige dieser Assignments sind _benotet_, d.h. die Qualität Ihrer Ausarbeitung geht in die Gesamtnote für diesen Kurs ein. Sie erkennen die _benoteten Assignments an dem Abgabedatum_, bis zu dem Ihre Lösung hochgeladen sein muss.

Hinweise zur nötigen Softwareausstattung finden Sie [hier](help/software.md).

| #  | Ausgabe    | Thema                                                                                     | Fällig am 📆   |
|----|------------|-------------------------------------------------------------------------------------------|----------------|
| 1. | 05.10.2023 | [Java-Klasse analysieren und patchen](Assignment_001/readme.md)                           |                |
| 2. | 05.10.2023 | [Dateien mit `file` untersuchen (files.zip)](Assignment_002/readme.md)                    |                |
| 3. | 12.10.2023 | [Importe mit rabin2 untersuchen (payload_1)](Assignment_003/readme.md)                    | **15.10.2023** |
| 4. | 12.10.2023 | [Exports und Imports mit rabin2 untersuchen (payload_2.so)](Assignment_004/readme.md)     | **15.10.2023** |
| 5. | 16.10.2023 | [Importe mit rabin2 untersuchen (payload_1b)](Assignment_005/readme.md)                   |                |
| 6. | 16.10.2023 | [Executable mit rabin2 und strace untersuchen (payload_1c)](Assignment_006/readme.md)     |                |
| 7. | 16.10.2023 | [Executable mit rabin2 und strace untersuchen (payload_1d)](Assignment_007/readme.md)     |                |
| 8. | 16.10.2023 | [Flag mit strings extrahieren (password_check_1 - 3)](Assignment_008/readme.md)           |                |
| 9. | 16.10.2023 | [Strings mit Hexeditor finden (password_check_3)](Assignment_009/readme.md)               |                |
| 10. | 16.10.2023 | [Strings mit rabin2 extrahieren (password_check_1 - 3)](Assignment_010/readme.md)         |                |
| 11. | 16.10.2023 | [Eingebettete Files (unknown_3)](Assignment_011/readme.md)                                | **22.10.2023** |
| 12. | 16.10.2023 | [Core Dump erstellen und analysieren (dumpme)](Assignment_012/readme.md)                  | **22.10.2023** |
| 13. | 23.10.2023 | [Speicherlayout eines Prozesses ausgeben](Assignment_013/readme.md)                       | **01.11.2023** |
| 14. | 02.11.2023 | [Disassemblieren mit Radare 2 (number_check_1)](Assignment_014/readme.md)                 |                |
| 15. | 02.11.2023 | [Executable mit Hex-Editor patchen (password_check_5)](Assignment_015/readme.md)          |                |
| 16. | 02.11.2023 | [Mit gdb debuggen (password_check_4)](Assignment_016/readme.md)                           | **08.11.2023** |
| 17. | 09.11.2023 | [Disassemblieren einer Payload (payload_3.bin)](Assignment_017/readme.md)                 |                |
| 18. | 09.11.2023 | [Disassemblieren einer verschleierten Payload (payload_4.bin)](Assignment_018/readme.md)  |                |
| 19. | 09.11.2023 | [String-Obfuscation (string_obfuscation)](Assignment_019/readme.md)                       | **15.11.2023** |
| 20. | 16.11.2023 | [Schwachstelle finden und ausnutzen (greeter_1)](Assignment_020/readme.md)                |                |
| 21. | 16.11.2023 | [Schwachstelle finden und ausnutzen (greeter_2)](Assignment_021/readme.md)                |                |
| 22. | 23.11.2023 | [Analyse mit Ghidra (buggy_hello_world)](Assignment_022/readme.md)                        | **23.11.2023** |
| 23. | 23.11.2023 | [Schwachstelle finden und ausnutzen (password_check_13)](Assignment_023/readme.md)        |                |
| 24. | 23.11.2023 | [Roundtrip mit Ghidra (roundtrip_1)](Assignment_024/readme.md)                            |                |
| 25. | 23.11.2023 | [Analyse mit Ghidra (license_check)](Assignment_025/readme.md)                            | **29.11.2023** |
| 26. | 30.11.2023 | [Roundtrip mit Ghidra (roundtrip_2)](Assignment_026/readme.md)                            |                |
| 27. | 30.11.2023 | [Roundtrip mit Ghidra (roundtrip_3)](Assignment_027/readme.md)                            |                |
| 28. | 30.11.2023 | [Analyse mit Ghidra (password_check_11)](Assignment_028/readme.md)                        | **06.12.2023** |
| 29. | 07.12.2023 | [Disassemblieren einer Payload (payload_7.bin)](Assignment_029/readme.md)                 |                |
| 30. | 07.12.2023 | [Analyse mit Ghidra (pwnable 21)](Assignment_030/readme.md)                               | **13.12.2023** |
| 31. | 14.12.2023 | [Analyse mit Ghidra (pwnable 23)](Assignment_031/readme.md)                               |                |
| 32. | 14.12.2023 | [Eigenes Crackme schreiben](Assignment_032/readme.md)                                     | **08.01.2024** |
| 33. | 11.01.2024 | [Crackme-Wettbewerb](Assignment_033/readme.md)                                            | **17.01.2024** |

## Benotung

Die Benotung des Kurses erfolgt im Format Continuous Assessment (CA). Hierzu werden Ihre Leistungen während des gesamten Semesters bewertet und die Endnote ergibt sich aus den Einzelleistungen.

Bewertet werden:

  * die erstellten Writeups und Lösungen zu den Assignments
  * die Erstellung neuer Aufgaben/CTFs durch die Teams (Peer-Aufgaben)
  * die Lösung der Peer-Aufgaben/CTFs durch die Teams

Alle mit einem Abgabedatum gekennzeichneten Assignments sind Teil der Bewertung und müssen von Ihnen bearbeitet und fristgerecht abgegeben werden.


## Hilfreiche Links und Tipps

  * [Typische Sicherheitslücken](help/sicherheitsluecken.md)
  * [Compiler Explorer](https://godbolt.org/)
  * [x86 and amd64 instruction reference](https://www.felixcloutier.com/x86/index.html)
  * [System V AMD64 ABI Calling Convention](https://en.wikipedia.org/wiki/X86_calling_conventions#System_V_AMD64_ABI)
    1. RDI <- 1st param (left to right)
    2. RSI <- 2nd param (left to right)
    3. RDX <- 3rd param (left to right)
    4. RCX <- 4th param (left to right)
    5. R8 <- 5th param (left to right)
    6. R9 <- 6th param (left to right)
    * Stack <- excess params (right to left)
    * RAX -> result
  * [Linux System Call Table for x86 64](http://blog.rchapman.org/posts/Linux_System_Call_Table_for_x86_64/)
  * [Linux System Call Convention](https://en.wikibooks.org/wiki/X86_Assembly/Interfacing_with_Linux)
    * RAX <- System call number
    1. RDI <- 1st param (left to right)
    2. RSI <- 2nd param (left to right)
    3. RDX <- 3rd param (left to right)
    4. R10 <- 4th param (left to right)
    5. R8 <- 5th param (left to right)
    6. R9 <- 6th param (left to right)
    * RAX -> result
  * [printf Formatierungszeichen](http://www2.hs-esslingen.de/~zomotor/home.fhtw-berlin.de/junghans/cref/FUNCTIONS/format.html)
  * [gdb Cheat Sheet](https://users.ece.utexas.edu/~adnan/gdb-refcard.pdf)


## Literatur zur Vorlesung

  * Sikorski, M. and Honig, A. (2012). Practical Malware Analysis: The Hands-On Guide to Dissecting Malicious Software. No Starch Press.
  * Andriesse, D. (2018). Practical Binary Analysis: Build Your Own Linux Tools for Binary Instrumentation, Analysis, and Disassembly. No Starch Press.
  * Eagle C. and Nance K. (2020). The Ghidra Book: The Definitive Guide. No Starch Press.
  * Yurichev, D. (2019). Reverse Engineering for Beginners. [Online](https://beginners.re/main.html)
  * [x86-64 Assembly Language Programming with Ubuntu](http://www.egr.unlv.edu/~ed/assembly64.pdf)
  * [Intel Dokumentation zu x86-64](https://software.intel.com/content/www/us/en/develop/articles/intel-sdm.html)
  * [System V ABI](https://raw.githubusercontent.com/wiki/hjl-tools/x86-psABI/x86-64-psABI-1.0.pdf)
