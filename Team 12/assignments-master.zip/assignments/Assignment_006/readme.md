# Assignment: Executable mit rabin2 und strace untersuchen (payload_1c)



In diesem Assignment geht es darum, Techniken kennenzulernen, die Autoren von Malware benutzen, um sich einer statischen Analyse zu entziehen. Hierzu werden wir erneut das `rabin2`-Tool aus dem Radare 2 Paket verwenden.


## Radare 2

Für diese Übung werden wir das Kommandozeilen-Reverse-Engineering-Werkzeug Radare 2 einsetzen. Sie finden Tipps zur Installation und Verwendung in der [Kurzanleitung](../help/radare2.md).

## Aufgabe

Das Werkzeug `rabin2` kann dazu verwendet werden, die importierten Funktionen und enthaltenen Strings einer Binärdatei zu untersuchen.

Nehmen Sie sich die folgende Datei vor und verwenden Sie `rabin2`, um sich die Importe (Option `-i`), Exporte (Option `-E`) und die enthaltenen Strings (Option `-z`) anzeigen zu lassen.

  * [payload_1c](payload_1c)


## Hinweis

Bei dem Executable handelt es sich um ein Programm unbekannter Funktionalität, wie man sie z.B. bei der Untersuchung von kompromittierten Rechner finden könnte. Es kann gut sein, dass es sich um eine _Malware_ handelt, welche bei der Ausführung Schaden verursacht, bis hin zur Zerstörung aller Daten auf dem Rechner. Deswegen sollten Sie die Datei __auf keinen Fall__ ohne Schutzmaßnahmen (virtuelle Maschine etc.) __ausführen__. Die hier vorgenommene Analyse kommt ohne Ausführung der Datei aus und ist insofern sicher auch ohne Schutzmaßnahmen durchführbar.

Sie müssen in der Realität damit rechnen, dass die Malware Schwachstellen in den von Ihnen verwendeten Werkzeugen nutzt, um bei einem Reverse-Engineering Ihren Rechner anzugreifen. Da wir uns hier in einem Übungskontext befinden, ignorieren wir dieses Problem.

Da die Analyse mit `rabin2` nicht sehr erfolgreich sein wird, haben Sie die Möglichkeit, mit dem Werkzeug `strace` die Aufrufe in das Betriebssystem zu untersuchen, welche die Datei macht. Hierzu ruft man `strace` mit dem Namen der ausführbaren Datei auf, z.B. `strace ./payload_1c`, auf.

Sie haben auch die Möglichkeit, Prozesse zu untersuchen, indem Sie sich mit `strace -p PID` an den Prozess mit der entsprechenden `PID` anhängen. Wenn Sie die Fehlermeldung `Operation not permitted` bekommen, müssen Sie das Kommando mit `sudo` aufrufen.

__Achtung:__ `strace` führt die Datei aus. Mit einer echten Malware sollten Sie dies nur in einer gesicherten Umgebung machen. Hier ist die Ausführung sicher, Sie sollten den Rechner aber nach Ihrer Untersuchung neu starten.

## Abgabe

  * Schreiben Sie auf, was Sie über die Datei herausgefunden haben.
  * Geben Sie eine Einschätzung ab, ob es sich möglicherweise um eine Malware handelt.
  * Welche Art von Malware könnte vorliegen? Was macht sie wahrscheinlich?
  * Was fällt Ihnen auf?

Die Abgabe erfolgt über das Repository, das Ihrem Team zugeordnet ist.