# Binwalk

[Binwalk](https://github.com/ReFirmLabs/binwalk) ist ein Reverse-Engineering-Werkzeug für die Kommandozeile. 

## Installation

Sie müssen Binwalk installieren, bevor Sie es benutzen können. Unter Ubuntu können Sie es einfach mit `sudo apt install binwalk` installieren.
