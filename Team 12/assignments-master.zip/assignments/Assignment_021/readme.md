# Assignment: Schwachstelle finden und ausnutzen (greeter_2)



In dem vorliegenden Binary befindet sich eine Schwachstelle, die Sie finden sollen und dann ausnutzen, um das im Programm gespeicherte Flag zu erhalten. Das Flag per Debugger zu extrahieren ist __keine__ gültige Lösung dieser Aufgabe.

Sie können zur Analyse Radare 2 oder Ghidra benutzen.


## Radare 2

Für diese Übung werden wir das Kommandozeilen-Reverse-Engineering-Werkzeug Radare 2 einsetzen. Sie finden Tipps zur Installation und Verwendung in der [Kurzanleitung](../help/radare2.md).


## Ghidra

Diese Aufgabe verwendet [Ghidra](https://ghidra-sre.org/), ein umfangreiches Reverse-Engineering-Tool, das von der NSA entwickelt und als Open-Source-Lösung frei zur Verfügung gestellt wird.

Laden Sie Ghidra herunter und installieren Sie es auf Ihrem Rechner.

## Aufgabe

Bitte analysieren Sie das folgende Executable, um eine Schwachstelle zu finden:

  * [greeter_2](greeter_2)

Wenn Sie eine Schwachstelle entdeckt haben, verwenden Sie diese, um das Flag auszugeben.

Gehen Sie, wenn Sie **Radare 2** benutzen, wie folgt vor:

  * Öffnen Sie das Executable mit Radare 2.
  * Suchen Sie nach der `main`-Funktion mithilfe der Suchfunktion (`s`).
  * Wechseln Sie in den _visuellen Modus_ des Disassemblers von `r2`, indem Sie `v` drücken. (Sie können die Anzeige nach rechts verbreitern, indem Sie RETURN drücken.)
  * Scrollen Sie durch das Assembler-Listing und versuchen Sie das Programm zu verstehen.
  * Richten Sie Ihr Augenmerk auf den Aufruf von Bibliotheksfunktionen und die Anzahl der übergebenen Parameter.
  * Wenn Sie eine Schwachstelle gefunden haben, versuchen Sie diese auszunutzen.

Sie können auch **Ghidra** benutzen, um das Programm zu analysieren:

  * Öffnen Sie das Executable in Ghidra
  * Suchen Sie die `main`-Funktion im _Symbol-Tree_
  * Versuchen Sie anhand des C-Codes im Decompiler-Fenster das Programm zu verstehen
  * Richten Sie Ihr Augenmerk auf den Aufruf von Bibliotheksfunktionen und die Anzahl der übergebenen Parameter.
  * Wenn Sie eine Schwachstelle gefunden haben, versuchen Sie diese auszunutzen.



## Das echte Flag erhalten

Das Executable enthält nicht direkt das Flag, sondern nur eine `win()`-Funktion, die das Flag ausgibt. Deswegen finden Sie auf der [CTF-Webseite](http://tank.informatik.hs-mannheim.de) die Information, wo Sie dem Executable das Flag entlocken können. Hier ist ein Netzwerkdienst angegeben, z.B. `tank.informatik.hs-mannheim.de:3001`, d.h. auf Port `3001` des Servers `tank.informatik.hs-mannheim.de` lauscht das Programm auf Ihre Eingaben. Der Server ist nur aus dem Hochschulnetz erreichbar.

Verwenden Sie *netcat* (`nc`), um Ihre Eingaben an das Programm zu senden:

```console
$ nc tank.informatik.hs-mannheim.de 3001
Enter your name: Thomas
Hello Thomas
```

`telnet` ist an dieser Stelle keine gute Wahl, weil es die Daten nicht immer roh überträgt.


## Flags sammeln

Wenn Sie das Flag erhalten haben, so tragen Sie das Flag bitte auf der [CTF-Webseite](http://tank.informatik.hs-mannheim.de) ein. Bei der ersten Benutzung legt sich jedes Team einen Benutzer an, der wie das Team heißt.


## Abgabe

  * Schreiben Sie auf, wie Sie vorgegangen sind, und zwar so, dass ein fachkundiger Dritter Ihre Schritte nachvollziehen kann.
  * Gab es Probleme?
  * Welche Information konnten Sie extrahieren?
  * Falls es ein Flag gab, wie lautete das Flag?

Die Abgabe erfolgt über das Repository, das Ihrem Team zugeordnet ist.

Bitte legen Sie im Wurzelverzeichnis Ihres Repos eine Datei `readme.md` an, die einen Überblick über die Assignments und Write-Ups liefert. Die WritUps sollten von dieser Datei aus verlinkt sein. Gestalten Sie das Repo so, dass man sich leicht und schnell zurechtfinden kann.